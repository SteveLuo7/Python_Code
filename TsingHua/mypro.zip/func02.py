def printMAX(a,b):
    '''比较两个值的大小'''

    if a > b:
        print(a)
    else:
        print(b)


printMAX(4,5)