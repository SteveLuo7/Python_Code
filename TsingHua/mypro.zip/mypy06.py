import time
import math

def today_time():
    start_time = time.time()
    return start_time /60 /60 /24 /30


print(today_time())


