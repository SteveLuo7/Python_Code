a = 3  #全局变量

def test01():
    b=4 #局部变量
    print(b*10)
    return

test01()
