def f1(*a,b,c):
    print(a,b,c)
    return

