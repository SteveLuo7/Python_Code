def AVG(a,b):
    print("两个数字的平均值为{}".format((a+b)/2))
    return  #return的两个作用 一个是返回值 一个是结束函数执行

AVG(4,9)


def test03(a,b,c):
    return [a*10,b*8,c]

print (test03(1,3,4))