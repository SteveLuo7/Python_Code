def test01(a,b,c,d):
    print("{},{},{},{}".format(a,b,c,d))

    return

test01(10,20,30,40)


test01(d=20,b=40,a=10,c=100)


