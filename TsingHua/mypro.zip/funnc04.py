def test01():
    print('test01')

test01()
c=test01

c()
print(id(test01))
print(id(c))
